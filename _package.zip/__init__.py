variables = variable_name
functions = functionName
classes = ClassName
