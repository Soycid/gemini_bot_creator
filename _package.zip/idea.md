Want scipting

If in a config file there is a response that is close enough to query, it uses old response

word2vec input -> cosine similarity -> if reaches .95 threshold -> use query

eg:
Are you a human?
(from config) No I am a catgirl
