from chai_py import TRoom

from bot import Replica

t_room = TRoom([Replica()])
t_room.chat()
