0. make conversational
1. put all metadata in a personality.toml file
2. make speech filtering
3. make keyword stuff from mistress mia
4. make memories
5. Add scripting
6. Add sentiment
7. 


BOT LIST:
1. Incest fam
2. FNAF fam
